package com.example.demo.controller;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.demo.entity.Admin;
import com.example.demo.entity.EmployeeRegister;
import com.example.demo.entity.LeaveRequest;
import com.example.demo.repository.AdminRepository;
import com.example.demo.repository.EmpRegisterRepo;
import com.example.demo.repository.LeaveRequestRepository;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/admin")
public class AdminLeaveController {

    @Autowired
    private LeaveRequestRepository leaveRequestRepository;
    @Autowired
    private EmpRegisterRepo employeeRegisterRepository;
    
    
    // Admin view of all leave requests
    @GetMapping("/leaves")
    public String showLeaveRequests(Model model) {
        model.addAttribute("leaves", leaveRequestRepository.findAll());
        List<LeaveRequest> leaves = leaveRequestRepository.findAllByOrderByCreatedDateDesc();
        model.addAttribute("leaves", leaves);
        return "admin_leave_requests";
    }

    // Approve leave request
    @PostMapping("/leaves/approve/{id}")
    public String approveLeave(@PathVariable Long id) {
        LeaveRequest request = leaveRequestRepository.findById(id).orElse(null);
        if (request != null) {
            request.setStatus("APPROVED");  // Update status to 'APPROVED'
            leaveRequestRepository.save(request); // Save updated request
        }
        return "redirect:/admin/leaves";  // Redirect to the list of leave requests
    }

    // Reject leave request
    @PostMapping("/leaves/reject/{id}")
    public String rejectLeave(@PathVariable Long id) {
        LeaveRequest request = leaveRequestRepository.findById(id).orElse(null);
        if (request != null) {
            request.setStatus("REJECTED");  // Update status to 'REJECTED'
            leaveRequestRepository.save(request); // Save updated request
        }
        return "redirect:/admin/leaves";  // Redirect to the list of leave requests
    }
    @PostMapping("/rejectLeave")
    public String rejectLeaveWithReason(@RequestParam("leaveId") Long leaveId,
                                        @RequestParam("rejectionReason") String rejectionReason,
                                        RedirectAttributes redirectAttributes) {
        LeaveRequest leave = leaveRequestRepository.findById(leaveId).orElse(null);

        if (leave != null) {
            leave.setStatus("REJECTED");
            leave.setRejectionReason(rejectionReason); // Save the reason
            leaveRequestRepository.save(leave);
            redirectAttributes.addFlashAttribute("message", "Leave rejected with reason.");
        } else {
            redirectAttributes.addFlashAttribute("error", "Leave not found.");
        }

        return "redirect:/admin/leaves"; // or wherever your approval page is
    }
    @GetMapping("/employees")
    public String showAllEmployees(Model model) {
        List<EmployeeRegister> employees = employeeRegisterRepository.findAll();
        model.addAttribute("employees", employees);
        return "admin_employee_list";  // Thymeleaf template
    }
    @GetMapping("/employee/edit/{id}")
    public String editEmployee(@PathVariable Long id, Model model) {
        EmployeeRegister employee = employeeRegisterRepository.findById(id).orElse(null);
        if (employee == null) {
            // Optionally add error message and redirect
            return "redirect:/admin/employees";
        }
        model.addAttribute("employee", employee);
        return "admin_employee_edit"; // Make sure this Thymeleaf file exists
    }
    @PostMapping("/employee/update")
    public String updateEmployee(@ModelAttribute EmployeeRegister employee, RedirectAttributes redirectAttributes) {
        employeeRegisterRepository.save(employee);  // Save updated employee
        redirectAttributes.addFlashAttribute("message", "Employee updated successfully.");
        return "redirect:/admin/employees";
    }
    @PostMapping("/employee/delete/{id}")
    public String deleteEmployee(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        
        Long pendingLeaves = leaveRequestRepository.countPendingLeaves(id);
        
        if (pendingLeaves != null && pendingLeaves > 0) {
            redirectAttributes.addFlashAttribute("errorMessage", "Cannot delete employee. Pending leave requests exist.");
            return "redirect:/admin/employees"; // Redirect back to employee list or appropriate page
        }

        employeeRegisterRepository.deleteById(id);
        redirectAttributes.addFlashAttribute("successMessage", "Employee deleted successfully!");
        return "redirect:/admin/employees";
    }
    @Autowired
    private EmpRegisterRepo employeeRepo;

    @Autowired
    private LeaveRequestRepository leaveRepo;

    @GetMapping("/dashboard")
    public String showDashboard(Model model) {
        long totalEmployees = employeeRepo.count();
        long pendingLeaves = leaveRepo.countPendingLeaves();

        model.addAttribute("totalEmployees", totalEmployees);
        model.addAttribute("pendingLeaves", pendingLeaves);
        return "admin_dashboard";
    }
    @Autowired
    private AdminRepository adminRepository;

    @GetMapping("/login")
    public String showLoginPage() {
        return "admin_login";
    }

    @PostMapping("/login")
    public String processLogin(@RequestParam String username,
                               @RequestParam String password,
                               HttpSession session,
                               Model model) {
        Admin admin = adminRepository.findByUsernameAndPassword(username, password);
        if (admin != null) {
            session.setAttribute("admin", admin);
            return "redirect:/admin/dashboard";
        } else {
            model.addAttribute("error", "Invalid credentials");
            return "admin_login";
        }
    }

  
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/admin/login";
    }






    
}
