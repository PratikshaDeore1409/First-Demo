package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.EmployeeRegister;
import com.example.demo.repository.EmpRegisterRepo;

@Service
public class EmpRegisterServ {

    @Autowired
    private EmpRegisterRepo employeeRegiRepo;

    public EmployeeRegister save(EmployeeRegister employeeRegi) {
        return employeeRegiRepo.save(employeeRegi);
    }

    public boolean userIdExists(String userId) {
        return employeeRegiRepo.findByUserId(userId) != null;
    }
}