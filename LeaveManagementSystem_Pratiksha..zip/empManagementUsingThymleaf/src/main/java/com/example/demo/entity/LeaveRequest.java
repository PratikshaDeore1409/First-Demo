package com.example.demo.entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity

@Table(name = "leave_request")
public class LeaveRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String leaveType;

    private LocalDate fromDate;
    private LocalDate toDate;

    @Column(length = 1000)
    private String reason;

    private long numberOfDays;
    private String rejectionReason; 

    public String getRejectionReason() {
		return rejectionReason;
	}

	public void setRejectionReason(String rejectionReason) {
		this.rejectionReason = rejectionReason;
	}

	@ManyToOne
    @JoinColumn(name = "employee_id")
    private EmployeeRegister employee; // Automatically assigned during login
   
    public boolean isHalfDay() {
		return halfDay;
	}

	public void setHalfDay(boolean halfDay) {
		this.halfDay = halfDay;
	}

	public String getHalfDayType() {
		return halfDayType;
	}

	public void setHalfDayType(String halfDayType) {
		this.halfDayType = halfDayType;
	}

	@Column(name = "half_day")
	private boolean halfDay;

	@Column(name = "half_day_type")
	private String halfDayType;
 

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getLeaveType() {
		return leaveType;
	}

	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}

	public LocalDate getFromDate() {
		return fromDate;
	}

	public void setFromDate(LocalDate fromDate) {
		this.fromDate = fromDate;
	}

	public LocalDate getToDate() {
		return toDate;
	}

	public void setToDate(LocalDate toDate) {
		this.toDate = toDate;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public long getNumberOfDays() {
		return numberOfDays;
	}

	public void setNumberOfDays(long numberOfDays) {
		this.numberOfDays = numberOfDays;
	}

	public EmployeeRegister getEmployee() {
		return employee;
	}

	public void setEmployee(EmployeeRegister employee) {
		this.employee = employee;
	}

    // Getters and setters
	private String status; // default

	public String getStatus() {
	    return status;
	}

	public void setStatus(String status) {
	    this.status = status;
	}

	public void setTotalDays(double d) {
		// TODO Auto-generated method stub
		
	}
	 @Column(name = "created_date")
	    private LocalDateTime createdDate;

	    @PrePersist
	    public void prePersist() {
	        this.createdDate = LocalDateTime.now();
	    }

	    public LocalDateTime getCreatedDate() {
	        return createdDate;
	    }

	    public void setCreatedDate(LocalDateTime createdDate) {
	        this.createdDate = createdDate;
	    }

	
}
