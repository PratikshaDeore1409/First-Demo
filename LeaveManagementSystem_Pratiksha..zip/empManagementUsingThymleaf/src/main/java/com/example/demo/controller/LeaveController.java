package com.example.demo.controller;

import java.time.temporal.ChronoUnit;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.demo.entity.EmployeeRegister;
import com.example.demo.entity.LeaveRequest;

import com.example.demo.repository.LeaveRequestRepository;

import jakarta.servlet.http.HttpSession;

@Controller
public class LeaveController {

 

    @Autowired
    private LeaveRequestRepository leaveRequestRepository;

    /**
     * Show the leave application form for the logged-in employee.
     */
    @GetMapping("/leaveForm")
    public String showLeaveForm(Model model, HttpSession session) {
        EmployeeRegister emp = (EmployeeRegister) session.getAttribute("loggedInEmployee");
        if (emp == null) return "redirect:/login";

        LeaveRequest leaveRequest = new LeaveRequest();
        leaveRequest.setEmployee(emp);
        model.addAttribute("leaveRequest", leaveRequest);

        model.addAttribute("employeeName", emp.getName()); // ✅ Add this line

        return "leaveForm";
    }

    /**
     * Handle submission of leave request form.
     */
    @PostMapping("/applyLeave")
    public String applyLeave(@ModelAttribute LeaveRequest leaveRequest,
                             HttpSession session,
                             RedirectAttributes redirectAttributes) {
        EmployeeRegister employee = (EmployeeRegister) session.getAttribute("loggedInEmployee");
        if (employee == null) {
            return "redirect:/login";
        }

        leaveRequest.setEmployee(employee);

        // Check for overlapping leave BEFORE saving
        List<LeaveRequest> overlappingLeaves = leaveRequestRepository.findOverlappingLeaves(
            employee.getId(),
            leaveRequest.getFromDate(),
            leaveRequest.getToDate()
        );

        if (!overlappingLeaves.isEmpty()) {
            redirectAttributes.addFlashAttribute("error", "You have already applied for leave on the selected dates.");
            return "redirect:/leaveForm";
        }

        // Calculate number of leave days
        if (leaveRequest.getFromDate() != null && leaveRequest.getToDate() != null) {
            long days = ChronoUnit.DAYS.between(leaveRequest.getFromDate(), leaveRequest.getToDate()) + 1;
            leaveRequest.setNumberOfDays(days);
        }

        // Handle half day logic
        if (leaveRequest.isHalfDay()) {
            leaveRequest.setTotalDays(0.5);
        } else {
            long days = ChronoUnit.DAYS.between(leaveRequest.getFromDate(), leaveRequest.getToDate()) + 1;
            leaveRequest.setTotalDays(days);
            leaveRequest.setHalfDayType(null); // Clear halfDayType if not half-day
        }

        // Set status and save
        leaveRequest.setStatus("PENDING");
        leaveRequestRepository.save(leaveRequest);

        redirectAttributes.addFlashAttribute("success", "Leave applied successfully.");
        return "redirect:/leaveForm";
    }

    /**
     * Display leave history for the logged-in employee.
     */
    @GetMapping("/myLeaves")
    public String viewMyLeaves(HttpSession session, Model model) {
        EmployeeRegister employee = (EmployeeRegister) session.getAttribute("loggedInEmployee");
        if (employee == null) {
            return "redirect:/login";
        }

        model.addAttribute("employee", employee);
        model.addAttribute("employeeName", employee.getName()); // ✅ Add this line
        model.addAttribute("leaves", leaveRequestRepository.findByEmployee(employee));

        return "my_leaves";
    }

    
}