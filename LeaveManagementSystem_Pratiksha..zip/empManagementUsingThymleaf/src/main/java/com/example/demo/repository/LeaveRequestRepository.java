package com.example.demo.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.entity.EmployeeRegister;
import com.example.demo.entity.LeaveRequest;

public interface LeaveRequestRepository extends JpaRepository<LeaveRequest, Long> {
	List<LeaveRequest> findByEmployeeUserId(String userId);
	List<LeaveRequest> findByEmployee(EmployeeRegister employee);
	long countByStatus(String status);
	long countByEmployeeIdAndStatus(Long employeeId, String status);
	@Query("SELECT lr FROM LeaveRequest lr WHERE lr.employee.id = :employeeId " +
		       "AND lr.status <> 'REJECTED' " +
		       "AND ((lr.fromDate <= :toDate AND lr.toDate >= :fromDate))")
		List<LeaveRequest> findOverlappingLeaves(@Param("employeeId") Long employeeId,
		                                         @Param("fromDate") LocalDate fromDate,
		                                         @Param("toDate") LocalDate toDate);
	@Query("SELECT COUNT(l) FROM LeaveRequest l WHERE l.employee.id = :employeeId AND l.status = 'Pending'")
	Long countPendingLeaves(@Param("employeeId") Long employeeId);
	@Query("SELECT COUNT(l) FROM LeaveRequest l WHERE l.status = 'Pending'")
	long countPendingLeaves();
	 List<LeaveRequest> findAllByOrderByCreatedDateDesc();



}
