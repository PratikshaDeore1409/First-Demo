package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;  // Correct import
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.entity.Employee;
import com.example.demo.entity.EmployeeRegister;
import com.example.demo.service.EmpService;
import com.example.demo.service.LeaveRequestService;

import jakarta.servlet.http.HttpSession;

@Controller
public class HomeController {

    @Autowired
    private EmpService empService;
    @Autowired
    private LeaveRequestService leaveRequestService;

    @GetMapping("/")
    public String index(HttpSession session, Model m) {
        List<Employee> list = empService.getAllEmp();
        m.addAttribute("empList", list);
        EmployeeRegister emp = (EmployeeRegister) session.getAttribute("loggedInEmployee");

        if (emp != null) {
            m.addAttribute("employee", emp); // ✅ Add full object
            m.addAttribute("employeeName", emp.getName()); // Optional: name only
        } else {
            return "redirect:/login"; // Or handle missing session
        }

        return "index";
    }
    

    @GetMapping("/dashboard")
    public String showDashboard(HttpSession session, Model model) {

        // Get the employee from session
        EmployeeRegister employee = (EmployeeRegister) session.getAttribute("loggedInEmployee");

        // If not logged in, redirect to login
        if (employee == null) {
            return "redirect:/login";
        }

        Long employeeId = employee.getId(); // Assuming getId() returns the employee's DB ID

        // Fetch leave counts by status for this employee
        long pending = leaveRequestService.getLeaveCountByStatus(employeeId, "PENDING");
        long approved = leaveRequestService.getLeaveCountByStatus(employeeId, "APPROVED");
        long rejected = leaveRequestService.getLeaveCountByStatus(employeeId, "REJECTED");

        // Add to model for Thymeleaf
        model.addAttribute("pendingCount", pending);
        model.addAttribute("approvedCount", approved);
        model.addAttribute("rejectedCount", rejected);

        // Also pass name for sidebar
        model.addAttribute("employeeName", employee.getName());

        
        return "dashboard";
    }
    

    
    @GetMapping("/loadEmpSave")
    public String loadEmpSave() {
        return "emp_save";
    }

    @GetMapping("/EditEmp/{id}")
    public String EditEmp(@PathVariable int id, Model m) {
        Employee emp = empService.getEmpById(id);
        m.addAttribute("emp", emp);
        return "edit_emp";
    }

    @PostMapping("/saveEmp")
    public String saveEmp(@ModelAttribute Employee emp, HttpSession session) {
        Employee newEmp = empService.saveEmp(emp);

        if (newEmp != null) {
            session.setAttribute("msg", "Register successfully");
        } else {
            session.setAttribute("msg", "Something went wrong on the server");
        }

        return "redirect:/loadEmpSave";
    }

    @PostMapping("/updateEmpDtls")
    public String updateEmp(@ModelAttribute Employee emp, HttpSession session) {
        Employee updateEmp = empService.saveEmp(emp);

        if (updateEmp != null) {
            session.setAttribute("msg", "Update successfully");
        } else {
            session.setAttribute("msg", "Something went wrong on the server");
        }

        return "redirect:/";
    }

    @GetMapping("/deleteEmp/{id}")
    public String deleteEmp(@PathVariable int id, HttpSession session) {
        boolean f = empService.deleteEmp(id);
        if (f) {
            session.setAttribute("msg", "Delete successfully");
        } else {
            session.setAttribute("msg", "Something went wrong on the server");
        }
        return "redirect:/";
    }
    
}
