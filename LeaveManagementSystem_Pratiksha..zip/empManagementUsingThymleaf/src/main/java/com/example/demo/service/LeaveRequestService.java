package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.LeaveRequest;
import com.example.demo.repository.LeaveRequestRepository;

import jakarta.transaction.Transactional;

@Service
public class LeaveRequestService {

    @Autowired
    private LeaveRequestRepository leaveRequestRepository;
    @Transactional
    public LeaveRequest saveLeaveRequest(LeaveRequest leaveRequest) {
        return leaveRequestRepository.save(leaveRequest);
    }
    public long getCountByStatus(String status) {
        return leaveRequestRepository.countByStatus(status);
    }
    public long getLeaveCountByStatus(Long employeeId, String status) {
        return leaveRequestRepository.countByEmployeeIdAndStatus(employeeId, status);
    }
}