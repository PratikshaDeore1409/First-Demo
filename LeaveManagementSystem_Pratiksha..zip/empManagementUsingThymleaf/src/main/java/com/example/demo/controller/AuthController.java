package com.example.demo.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.entity.EmployeeRegister;
import com.example.demo.entity.LoginRequest;
import com.example.demo.repository.EmpRegisterRepo;

import jakarta.servlet.http.HttpSession;

@Controller
public class AuthController {

	 @Autowired
	    private EmpRegisterRepo employeeRegiRepository;

	    @GetMapping("/login")
	    public String showLoginPage(Model model) {
	        model.addAttribute("loginRequest", new LoginRequest());
	        return "login";
	    }

	    @PostMapping("/login")
	    public String doLogin(@ModelAttribute("loginRequest") LoginRequest loginRequest, Model model, HttpSession session) {
	        Optional<EmployeeRegister> employee = employeeRegiRepository.findByUserIdAndPassword(
	                loginRequest.getUserId(),
	                loginRequest.getPassword()
	        );

	        if (employee.isPresent()) {
	        	
	            session.setAttribute("loggedInEmployee", employee.get());
	            return "redirect:/dashboard";
	        } else {
	            model.addAttribute("error", "Invalid user ID or password");
	            return "login";
	        }
	        
	    }


    @GetMapping("/logout")
    public String logout(Model model) {
        model.addAttribute("logout", "You have been logged out successfully.");
        return "login";
    }
}
