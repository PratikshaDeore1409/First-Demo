package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.EmployeeRegister;
import com.example.demo.service.EmpRegisterServ;

@Controller
public class EmployeeController {

    @Autowired
    private EmpRegisterServ empregisterserv;

    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("employeeregi", new EmployeeRegister());
        return "registration"; // your HTML filename
    }

    @PostMapping("/register")
    public String processRegistration(@ModelAttribute("employeeregi") EmployeeRegister employeeregi, Model model) {
        if (empregisterserv.userIdExists(employeeregi.getUserId())) {
            model.addAttribute("errorMessage", "User ID already exists!");
            return "registration";
        }

        empregisterserv.save(employeeregi);
        model.addAttribute("successMessage", "Registration successful!");
        return "registration"; // same view but with success message
    }
  

}