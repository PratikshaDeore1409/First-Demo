package com.example.demo.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.EmployeeRegister;

public interface EmpRegisterRepo extends JpaRepository<EmployeeRegister, Long> {
	EmployeeRegister findByUserId(String userId); // for login, optional
	
	 
	Optional<EmployeeRegister> findByUserIdAndPassword(String userId, String password);
	long count(); //biult in
}
